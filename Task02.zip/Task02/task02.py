import re
import math

# Sample dataset
data = {
    'Greet': ["Hi", "How are you?", "Hello"],
    'Farewell': ["Goodbye", "See you later", "Take care"],
    'Inquiry': ["What's the weather like today?", "Can you tell me the time?", "Where is the nearest restaurant?"]
}

# Preprocessing functions
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text

# Training
word_counts = {}
total_words = 0
intent_counts = {}
for intent, examples in data.items():
    intent_counts[intent] = len(examples)
    for example in examples:
        preprocessed_example = preprocess_text(example)
        words = preprocessed_example.split()
        for word in words:
            word_counts.setdefault(intent, {}).setdefault(word, 0)
            word_counts[intent][word] += 1
            total_words += 1

# Classification function with fallback mechanism
def classify_intent(text, threshold=0.7):
    preprocessed_text = preprocess_text(text)
    words = preprocessed_text.split()
    
    scores = {}
    for intent, intent_word_counts in word_counts.items():
        scores[intent] = math.log(intent_counts[intent] / sum(intent_counts.values()))  # Prior probability
        for word in words:
            word_count = intent_word_counts.get(word, 0) + 1  # Add-one smoothing
            scores[intent] += math.log(word_count / (total_words + len(set(word_counts[intent]))))  # Conditional probability

    max_intent = max(scores, key=scores.get)
    max_score = scores[max_intent]
    
    confidence = max_score / sum(scores.values())
    
    if confidence >= threshold:
        return max_intent, confidence
    else:
        return "NLU fallback: Intent could not be confidently determined", confidence

# Testing
test_texts = [
    "Hi there!",
    "What's up?",
    "Goodbye, see you tomorrow.",
    "Where can I find a good restaurant?"
]

for text in test_texts:
    intent, confidence = classify_intent(text)
    print(f"Text: '{text}' | Intent: {intent} | Confidence: {confidence}")
